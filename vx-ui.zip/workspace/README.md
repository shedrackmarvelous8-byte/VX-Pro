# VX — Core Chat UI

Mobile-first AI development workspace (UI only — no backend, no AI calls).

```
npm install && npm run dev
```

## Structure
```
src/
  app/App.tsx                 # Composition root: wires state → layout
  styles/tokens.css           # Design tokens (colors, radius, spacing, type, motion)
  styles/global.css           # Reset + base
  types/chat.ts               # Message / Conversation / Project / InputMode
  data/placeholder.ts         # Demo content only
  hooks/
    useWorkspace.ts           # Client state (swap internals for real data later)
    useViewportHeight.ts      # Keyboard-safe --app-height via visualViewport
    useAutoResize.ts          # Growing textarea
    useMediaQuery.ts
  components/
    layout/AppShell           # [sidebar][main][aside] — aside reserved for Plan/Code/Preview panels
    header/Header             # Menu · Project · "Model"
    sidebar/
      Sidebar                 # Drawer (<1024px, swipe/Esc/scrim to close) · docked + collapsible ≥1024px
      SidebarSection, NavItem # Section label + 44px icon rows
      ProjectList             # Projects with stack · last-updated meta
      RecentList              # Recents (pinned first) + inline rename
      ConversationMenu        # Share · Rename · Pin · Add to project › · Move › · Archive · Delete
      navigation.ts           # Dev surface registry (Preview, Code, Terminal, Database, Environment, GitHub)
      useSwipeToClose.ts
  models/ModelSheet          # Model picker sheet (search, groups, badges, selected state)
  voice/VoicePanel           # Live voice mode of the same conversation (UI only)
  agent/
    AgentCard                # Shared VX card chrome for contextual cards
    AgentFlow                # Build Plan → (Generate | Skip) → agent activity
    PlanCard                 # Temporary contextual Build Plan
    PlanCustomizeSheet       # Style/Colors/Pages/Features/Animations/Extra edits
    AgentActivityCard        # Expandable agent run: steps, results, next steps
    ApprovalCard             # Major-change approval (Review/Approve/Cancel)
    planOptions              # Option sets + plan ↔ customization mapping
  ui/Sheet                   # Bottom sheet / centered dialog primitive
    chat/MessageList, Message, EmptyState, ScrollToBottom
    composer/Composer         # Text ⇄ Voice mode in the same composer, attachments, send
    markdown/Markdown, CodeBlock, highlight   # Dependency-free markdown + code rendering
    ui/Icon, IconButton       # 44px touch-target primitives
    ui/Menu                   # Anchored popover menu (flip/clamp, keyboard nav, sub-views)
    ui/ConfirmDialog          # Native <dialog> confirm
    ui/Toast                  # Single-slot toast with optional Undo
  app/useConversationActions.ts  # Menu actions → local state + feedback (no backend)
```

## Extension points
- **Model picker**: `Header` → `onOpenModel` prop.
- **Voice**: `InputMode` in `useWorkspace`; the composer's voice state is where the voice UI plugs in.
- **Plan / Build / Code / Preview**: pass contextual panels into `AppShell`'s `aside` slot.
  The sidebar already sets `ws.surface` (`'files' | 'preview' | 'code' | 'terminal' | 'database' | 'environment' | 'github'`);
  render the matching panel from that value and remove the placeholder toast in `App.openSurface`.
- **Conversation actions**: swap the in-memory reducer cases in `useWorkspace` for real calls; the UI needs no changes.
- **Model picker**: `ModelSheet` takes placeholder `models` from `data/placeholder.ts` — swap in real
  model metadata (still provider-free) and lift `selectedId` into app state.
- **Voice**: `VoicePanel` cycles placeholder states on a timer — replace with real voice events;
  `InputMode` already threads mode through `useWorkspace` → `Composer`.
- **Agent cards**: `AgentActivityCard live` walks steps on a demo timer (`onOpenPreview` is wired to
  `openSurface('preview')`); connect real agent events by feeding `Message.kind` payloads
  (`plan` / `activity` / `approval`) in `types/chat.ts`.
