import { Icon } from '../ui/Icon'
import { IconButton } from '../ui/IconButton'
import './Header.css'

interface HeaderProps {
  /** Hide the menu button when a docked sidebar is already visible (desktop) */
  hideMenu?: boolean
  projectName: string
  sidebarOpen: boolean
  scrolled: boolean
  onToggleSidebar: () => void
  onOpenProject?: () => void
  onOpenModel?: () => void
}

export function Header({ projectName, hideMenu, sidebarOpen, scrolled, onToggleSidebar, onOpenProject, onOpenModel }: HeaderProps) {
  return (
    <header className="header" data-menu-hidden={hideMenu || undefined} data-scrolled={scrolled || undefined}>
      <div className="header__left">
        {!hideMenu && (
        <IconButton
          icon="menu"
          label={sidebarOpen ? 'Close sidebar' : 'Open sidebar'}
          aria-expanded={sidebarOpen}
          aria-controls="sidebar"
          onClick={onToggleSidebar}
          className="header__menu"
        />
        )}
        <button type="button" className="header__project" onClick={onOpenProject} aria-label={`Project: ${projectName}`}>
          <span className="header__project-name">{projectName}</span>
          <Icon name="chevronDown" size={16} className="header__chevron" />
        </button>
      </div>

      {/* Model picker is wired in a later step — label intentionally provider-agnostic. */}
      <button type="button" className="header__model" onClick={onOpenModel} aria-haspopup="dialog">
        <span>Model</span>
        <Icon name="chevronDown" size={15} />
      </button>
    </header>
  )
}
