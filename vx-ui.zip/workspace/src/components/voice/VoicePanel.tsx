import { useEffect, useRef, useState, type CSSProperties } from 'react'
import { Icon } from '../ui/Icon'
import { IconButton } from '../ui/IconButton'
import './VoicePanel.css'

type VoiceState = 'listening' | 'speaking' | 'responding'

const labels: Record<VoiceState, string> = {
  listening: 'Listening...',
  speaking: 'Speaking...',
  responding: 'AI is responding...',
}

const cycle: VoiceState[] = ['listening', 'speaking', 'responding']

/** Per-bar amplitude seed for the activity visualization. */
const BARS = [0.45, 0.7, 0.35, 0.9, 0.55, 0.3, 0.75, 0.5, 0.95, 0.6, 0.4, 0.8, 0.5, 0.65, 0.35, 0.85, 0.45, 0.7, 0.4, 0.8, 0.5]

interface VoicePanelProps {
  /** Return to the text composer — the same conversation stays in place. */
  onExit: () => void
}

/**
 * Live voice surface (UI only — no real voice/audio yet).
 * Voice is simply another communication mode of the current conversation.
 */
export function VoicePanel({ onExit }: VoicePanelProps) {
  const [state, setState] = useState<VoiceState>('listening')
  const [muted, setMuted] = useState(false)
  const exitRef = useRef<HTMLButtonElement>(null)

  // Demo pacing for the listening / speaking / responding states.
  // Replaced by real voice events when the voice backend is connected later.
  useEffect(() => {
    if (muted) return
    const id = window.setInterval(() => {
      setState((s) => cycle[(cycle.indexOf(s) + 1) % cycle.length])
    }, 3200)
    return () => window.clearInterval(id)
  }, [muted])

  useEffect(() => {
    exitRef.current?.focus()
  }, [])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onExit()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onExit])

  const status = muted ? 'Microphone off' : labels[state]

  return (
    <section className="voice" data-muted={muted || undefined} data-state={muted ? 'muted' : state} aria-label="Voice mode">
      <div className="voice__top">
        <p className="voice__status" role="status">
          <span className="voice__dot" aria-hidden="true" />
          {status}
        </p>
        <IconButton ref={exitRef} icon="close" label="End voice" onClick={onExit} />
      </div>

      <div className="voice__wave" aria-hidden="true">
        {BARS.map((h, i) => (
          <span
            key={i}
            className="voice__bar"
            style={
              {
                '--h': h,
                animationDelay: `${(i % 6) * 90}ms`,
                animationDuration: `${980 + (i % 5) * 130}ms`,
              } as CSSProperties
            }
          />
        ))}
      </div>

      <div className="voice__controls">
        <button
          type="button"
          className="voice__mic"
          aria-pressed={muted}
          aria-label={muted ? 'Unmute microphone' : 'Mute microphone'}
          onClick={() => setMuted((m) => !m)}
        >
          <Icon name={muted ? 'micOff' : 'mic'} size={22} />
        </button>
        <button type="button" className="voice__type" onClick={onExit}>
          <Icon name="keyboard" size={19} />
          Type instead
        </button>
      </div>
      <p className="voice__hint">Voice continues this conversation</p>
    </section>
  )
}
