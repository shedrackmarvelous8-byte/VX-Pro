import { useEffect, useMemo, useRef, useState } from 'react'
import type { ModelInfo } from '../../types/chat'
import { Icon } from '../ui/Icon'
import { IconButton } from '../ui/IconButton'
import { Sheet } from '../ui/Sheet'
import './ModelSheet.css'

interface ModelSheetProps {
  open: boolean
  onClose: () => void
  models: ModelInfo[]
  selectedId: string
  onSelect: (id: string) => void
}

const groups: { key: ModelInfo['group']; label: string }[] = [
  { key: 'recommended', label: 'Recommended' },
  { key: 'more', label: 'More models' },
]

/**
 * Model picker — shows model names and capabilities only.
 * Provider/API details are backend concerns and never appear here.
 */
export function ModelSheet({ open, onClose, models, selectedId, onSelect }: ModelSheetProps) {
  const [query, setQuery] = useState('')
  const searchRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (!open) return
    setQuery('')
    const id = requestAnimationFrame(() => searchRef.current?.focus())
    return () => cancelAnimationFrame(id)
  }, [open])

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return models
    return models.filter((m) =>
      [m.name, m.description, ...(m.badges ?? [])].join(' ').toLowerCase().includes(q),
    )
  }, [models, query])

  return (
    <Sheet open={open} onClose={onClose} title="Select model">
      <div className="model-search">
        <Icon name="search" size={17} className="model-search__icon" />
        <input
          ref={searchRef}
          type="search"
          className="model-search__input"
          placeholder="Search models..."
          aria-label="Search models"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          autoComplete="off"
          enterKeyHint="search"
        />
        {query.length > 0 && (
          <IconButton
            icon="close"
            label="Clear search"
            size="sm"
            className="model-search__clear"
            onClick={() => {
              setQuery('')
              searchRef.current?.focus()
            }}
          />
        )}
      </div>

      {filtered.length === 0 ? (
        <p className="model-empty">No models match “{query.trim()}”.</p>
      ) : (
        <div className="model-list" role="radiogroup" aria-label="Models">
          {groups.map((g) => {
            const items = filtered.filter((m) => m.group === g.key)
            if (items.length === 0) return null
            return (
              <section key={g.key} className="model-group">
                <h3 className="model-group__label">{g.label}</h3>
                {items.map((m) => {
                  const selected = m.id === selectedId
                  return (
                    <button
                      key={m.id}
                      type="button"
                      role="radio"
                      aria-checked={selected}
                      className="model-item"
                      data-selected={selected || undefined}
                      onClick={() => {
                        onSelect(m.id)
                        onClose()
                      }}
                    >
                      <span className="model-item__main">
                        <span className="model-item__name">{m.name}</span>
                        <span className="model-item__desc">{m.description}</span>
                        {m.badges && m.badges.length > 0 && (
                          <span className="model-item__badges">
                            {m.badges.map((b) => (
                              <span key={b} className="model-badge">
                                {b}
                              </span>
                            ))}
                          </span>
                        )}
                      </span>
                      <span className="model-item__check" aria-hidden="true">
                        {selected && <Icon name="check" size={18} strokeWidth={2.2} />}
                      </span>
                    </button>
                  )
                })}
              </section>
            )
          })}
        </div>
      )}
    </Sheet>
  )
}
