import { useCallback, useMemo, useReducer } from 'react'
import { conversations as seedConversations, projects as seedProjects } from '../data/placeholder'
import type { Attachment, Conversation, InputMode, Surface } from '../types/chat'

/**
 * Local UI state for the workspace. Pure client state — no backend, no AI, nothing persisted.
 * Later prompts can replace the reducer internals with real data sources
 * while keeping this hook's public API stable.
 */
interface State {
  projectId: string
  conversations: Conversation[]
  activeId: string | null
  mode: InputMode
  /** Contextual surface selected from the sidebar (rendered in AppShell's aside slot in a later step) */
  surface: Surface | null
}

type Action =
  | { type: 'select'; id: string }
  | { type: 'new' }
  | { type: 'send'; text: string; attachments: Attachment[] }
  | { type: 'mode'; mode: InputMode }
  | { type: 'project'; id: string }
  | { type: 'surface'; surface: Surface | null }
  | { type: 'rename'; id: string; title: string }
  | { type: 'pin'; id: string }
  | { type: 'move'; id: string; projectId: string }
  | { type: 'archive'; id: string; archived: boolean }
  | { type: 'delete'; id: string }
  | { type: 'restore'; convo: Conversation }

const uid = () => Math.random().toString(36).slice(2, 10)

const patch = (list: Conversation[], id: string, fn: (c: Conversation) => Conversation) =>
  list.map((c) => (c.id === id ? fn(c) : c))

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'select': {
      const convo = state.conversations.find((c) => c.id === action.id)
      return { ...state, activeId: action.id, projectId: convo?.projectId ?? state.projectId }
    }
    case 'new':
      return { ...state, activeId: null }
    case 'mode':
      return { ...state, mode: action.mode }
    case 'project':
      return { ...state, projectId: action.id, activeId: null }
    case 'surface':
      return { ...state, surface: action.surface }
    case 'rename':
      return { ...state, conversations: patch(state.conversations, action.id, (c) => ({ ...c, title: action.title })) }
    case 'pin':
      return { ...state, conversations: patch(state.conversations, action.id, (c) => ({ ...c, pinned: !c.pinned })) }
    case 'move':
      return {
        ...state,
        conversations: patch(state.conversations, action.id, (c) => ({ ...c, projectId: action.projectId })),
        projectId: state.activeId === action.id ? action.projectId : state.projectId,
      }
    case 'archive':
      return {
        ...state,
        conversations: patch(state.conversations, action.id, (c) => ({ ...c, archived: action.archived })),
        activeId: action.archived && state.activeId === action.id ? null : state.activeId,
      }
    case 'delete':
      return {
        ...state,
        conversations: state.conversations.filter((c) => c.id !== action.id),
        activeId: state.activeId === action.id ? null : state.activeId,
      }
    case 'restore':
      return { ...state, conversations: [...state.conversations, action.convo] }
    case 'send': {
      const msg = {
        id: uid(),
        role: 'user' as const,
        content: action.text,
        attachments: action.attachments.length ? action.attachments : undefined,
        createdAt: Date.now(),
      }
      if (!state.activeId) {
        const convo: Conversation = {
          id: uid(),
          projectId: state.projectId,
          title: action.text.split('\n')[0].slice(0, 60) || 'New conversation',
          messages: [msg],
          updatedAt: Date.now(),
        }
        return { ...state, conversations: [convo, ...state.conversations], activeId: convo.id }
      }
      return {
        ...state,
        conversations: patch(state.conversations, state.activeId, (c) => ({
          ...c,
          messages: [...c.messages, msg],
          updatedAt: Date.now(),
        })),
      }
    }
  }
}

export function useWorkspace() {
  const [state, dispatch] = useReducer(reducer, {
    projectId: seedProjects[0].id,
    conversations: seedConversations,
    activeId: null,
    mode: 'text',
    surface: null,
  })

  const project = seedProjects.find((p) => p.id === state.projectId)!
  const active = useMemo(
    () => state.conversations.find((c) => c.id === state.activeId) ?? null,
    [state.conversations, state.activeId],
  )

  /** ChatGPT-style recents: all projects, pinned first, then most recent. Archived hidden. */
  const recents = useMemo(
    () =>
      state.conversations
        .filter((c) => !c.archived)
        .sort((a, b) => Number(!!b.pinned) - Number(!!a.pinned) || b.updatedAt - a.updatedAt),
    [state.conversations],
  )

  const getConversation = useCallback(
    (id: string) => state.conversations.find((c) => c.id === id),
    [state.conversations],
  )

  return {
    project,
    projects: seedProjects,
    recents,
    /** @deprecated kept for API stability — conversations in the current project */
    conversations: recents.filter((c) => c.projectId === state.projectId),
    active,
    mode: state.mode,
    surface: state.surface,
    getConversation,
    selectConversation: useCallback((id: string) => dispatch({ type: 'select', id }), []),
    newConversation: useCallback(() => dispatch({ type: 'new' }), []),
    send: useCallback(
      (text: string, attachments: Attachment[] = []) => dispatch({ type: 'send', text, attachments }),
      [],
    ),
    setMode: useCallback((mode: InputMode) => dispatch({ type: 'mode', mode }), []),
    selectProject: useCallback((id: string) => dispatch({ type: 'project', id }), []),
    setSurface: useCallback((surface: Surface | null) => dispatch({ type: 'surface', surface }), []),
    renameConversation: useCallback((id: string, title: string) => dispatch({ type: 'rename', id, title }), []),
    togglePin: useCallback((id: string) => dispatch({ type: 'pin', id }), []),
    moveConversation: useCallback((id: string, projectId: string) => dispatch({ type: 'move', id, projectId }), []),
    setArchived: useCallback((id: string, archived: boolean) => dispatch({ type: 'archive', id, archived }), []),
    deleteConversation: useCallback((id: string) => dispatch({ type: 'delete', id }), []),
    restoreConversation: useCallback((convo: Conversation) => dispatch({ type: 'restore', convo }), []),
  }
}

export type Workspace = ReturnType<typeof useWorkspace>
