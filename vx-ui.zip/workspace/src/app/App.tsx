import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react'
import { Composer, type ComposerHandle } from '../components/composer/Composer'
import { EmptyState } from '../components/chat/EmptyState'
import { MessageList } from '../components/chat/MessageList'
import { ScrollToBottom } from '../components/chat/ScrollToBottom'
import { Header } from '../components/header/Header'
import { AppShell } from '../components/layout/AppShell'
import { ModelSheet } from '../components/models/ModelSheet'
import { Sidebar } from '../components/sidebar/Sidebar'
import { surfaceLabel } from '../components/sidebar/navigation'
import { ConfirmDialog } from '../components/ui/ConfirmDialog'
import { useToast } from '../components/ui/Toast'
import { defaultModelId, fileCounts, models } from '../data/placeholder'
import type { Surface } from '../types/chat'
import { useConversationActions } from './useConversationActions'
import { useMediaQuery } from '../hooks/useMediaQuery'
import { useViewportHeight } from '../hooks/useViewportHeight'
import { useWorkspace } from '../hooks/useWorkspace'

export function App() {
  useViewportHeight()
  const ws = useWorkspace()
  const toast = useToast()
  const actions = useConversationActions(ws)
  const docked = useMediaQuery('(min-width: 1024px)')
  const [sidebarOpen, setSidebarOpen] = useState(docked)
  const [scrolled, setScrolled] = useState(false)
  const [awayFromBottom, setAwayFromBottom] = useState(false)
  const [modelOpen, setModelOpen] = useState(false)
  const [modelId, setModelId] = useState(defaultModelId)
  const threadRef = useRef<HTMLDivElement>(null)
  const composerRef = useRef<ComposerHandle>(null)

  // Sidebar default follows breakpoint (docked open on desktop, closed drawer on mobile)
  useEffect(() => setSidebarOpen(docked), [docked])

  const messages = ws.active?.messages ?? []

  const scrollToBottom = useCallback((smooth = true) => {
    const el = threadRef.current
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: smooth ? 'smooth' : 'auto' })
  }, [])

  // Jump to latest when switching conversation or when a new message is appended
  useLayoutEffect(() => { scrollToBottom(false) }, [ws.active?.id, scrollToBottom])
  useEffect(() => { scrollToBottom(true) }, [messages.length, scrollToBottom])

  const onScroll = () => {
    const el = threadRef.current
    if (!el) return
    setScrolled(el.scrollTop > 4)
    setAwayFromBottom(el.scrollHeight - el.scrollTop - el.clientHeight > 160)
  }

  const closeSidebar = useCallback(() => setSidebarOpen(false), [])

  // Surfaces are contextual panels that open beside the chat in a later step.
  // For now we only record the selection and acknowledge it — the conversation stays in place.
  const openSurface = useCallback(
    (s: Surface) => {
      ws.setSurface(s)
      toast({ message: `${surfaceLabel(s)} opens here in a later step` })
    },
    [ws, toast],
  )

  return (
    <AppShell
      sidebar={
        <Sidebar
          open={sidebarOpen}
          docked={docked}
          project={ws.project}
          projects={ws.projects}
          fileCount={fileCounts[ws.project.id]}
          recents={ws.recents}
          activeId={ws.active?.id ?? null}
          surface={ws.surface}
          onClose={closeSidebar}
          onNew={() => { ws.newConversation(); requestAnimationFrame(() => composerRef.current?.focus()) }}
          onSearch={() => toast({ message: 'Search comes in a later step' })}
          onSelect={ws.selectConversation}
          onSelectProject={ws.selectProject}
          onNewProject={() => toast({ message: 'Creating projects comes in a later step' })}
          onOpenSurface={openSurface}
          onRename={ws.renameConversation}
          onConversationAction={actions.onAction}
        />
      }
    >
      <Header
        projectName={ws.project.name}
        hideMenu={docked && sidebarOpen}
        sidebarOpen={sidebarOpen}
        scrolled={scrolled}
        onToggleSidebar={() => setSidebarOpen((o) => !o)}
        onOpenModel={() => setModelOpen(true)}
      />
      <MessageList
        ref={threadRef}
        messages={messages}
        onScroll={onScroll}
        onOpenPreview={() => openSurface('preview')}
        empty={<EmptyState projectName={ws.project.name} onPick={(t) => composerRef.current?.setText(t)} />}
      />
      <div style={{ position: 'relative' }}>
        <ScrollToBottom visible={awayFromBottom && messages.length > 0} onClick={() => scrollToBottom()} />
        <Composer ref={composerRef} mode={ws.mode} onModeChange={ws.setMode} onSend={ws.send} />
      </div>
      <ConfirmDialog
        open={!!actions.pendingDelete}
        title="Delete conversation?"
        confirmLabel="Delete"
        danger
        onConfirm={actions.confirmDelete}
        onCancel={actions.cancelDelete}
      >
        This will delete <strong>{actions.pendingDelete?.title}</strong>.
      </ConfirmDialog>
      <ModelSheet
        open={modelOpen}
        onClose={() => setModelOpen(false)}
        models={models}
        selectedId={modelId}
        onSelect={setModelId}
      />
    </AppShell>
  )
}
